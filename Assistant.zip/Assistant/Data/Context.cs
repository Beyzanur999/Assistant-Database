﻿using Microsoft.EntityFrameworkCore;
using Assistant.Models;
using System.Collections.Generic;


namespace Assistant.Data
{
  
          public class Context : DbContext
        {
            public Context(DbContextOptions<Context> options) : base(options) { }

            public DbSet<Question> Questions { get; set; }
            public DbSet<Answer> Answers { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Question>()
                .HasOne(s => s.Answer)
                .WithOne(c => c.Question)
                .HasForeignKey<Answer>(c => c.QuestionId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }

    

}
