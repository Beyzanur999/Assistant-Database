﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

public class OpenAiService
{
    private readonly HttpClient _httpClient;
    private readonly string _apiKey;

    public OpenAiService(IConfiguration configuration)
    {
        _httpClient = new HttpClient();
        _apiKey = configuration["OpenAI:ApiKey"];
    }

    public async Task<string> GetOpenAiResponse(string question)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(_apiKey))
            {
                Console.WriteLine("OpenAI API anahtarı bulunamadı!");
                return "API anahtarı eksik!";
            }

            var requestBody = new
            {
                model = "gpt-3.5-turbo",
                messages = new[]
                {
                    new { role = "system", content = "Sen bir asistan'sın." },
                    new { role = "user", content = question }
                },
                temperature = 0.7
            };

            var requestJson = JsonSerializer.Serialize(requestBody);
            var content = new StringContent(requestJson, Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");

            Console.WriteLine($"OpenAI API'ye İstek Gönderiliyor: {question}");

            var response = await _httpClient.PostAsync("https://api.openai.com/v1/chat/completions", content);

            if (!response.IsSuccessStatusCode)
            {
                Console.WriteLine($"OpenAI API Hatası: {response.StatusCode}");
                return $"API hatası: {response.StatusCode}";
            }

            var responseJson = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"OpenAI API Yanıtı: {responseJson}");

            using var doc = JsonDocument.Parse(responseJson);
            var answer = doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString();

            return answer ?? "Yanıt alınamadı.";
        }
        catch (Exception ex)
        {
            Console.WriteLine($"OpenAI API İstek Hatası: {ex.Message}");
            return "Bir hata oluştu!";
        }
    }
}
