﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Assistant.Data;
using Assistant.Models;
using System;
using System.Threading.Tasks;



[Route("api/assistant")]
[ApiController]
public class AssistantController : ControllerBase
{
    private readonly Context _context;
    private readonly OpenAiService _openAiService;

    public AssistantController(Context context, OpenAiService openAiService)
    {
        _context = context;
        _openAiService = openAiService;
    }

    [HttpPost("ask")]
    public async Task<IActionResult> AskQuestion([FromBody] QuestionModel model)
    {
        if (string.IsNullOrWhiteSpace(model.Question))
            return BadRequest("Soru boş olamaz!");

        var question = new Question { Text = model.Question };
        _context.Questions.Add(question);
        await _context.SaveChangesAsync();


        string assistantAnswer = await _openAiService.GetOpenAiResponse(model.Question);

        var answer = new Answer { QuestionId = question.Id, Text = assistantAnswer };
        _context.Answers.Add(answer);
        await _context.SaveChangesAsync();

        return Ok(new { answer = assistantAnswer });
    }
}

public class QuestionModel
{
    public string? Question { get; set; }
}




