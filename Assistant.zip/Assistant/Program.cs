using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.OpenApi.Models;
using Assistant.Models;

namespace Assistant
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllers();
            builder.Services.AddAuthorization(); 

           
          

            // ?? Veritaban� ba�lant�s�n� ekle
            builder.Services.AddDbContext<Data.Context>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            builder.Services.AddSingleton<OpenAiService>();





            var app = builder.Build();

            

            app.UseHttpsRedirection();
            app.UseAuthorization();
            app.MapControllers();

            app.UseFileServer(new FileServerOptions
            {
                FileProvider = new PhysicalFileProvider(
           Path.Combine(builder.Environment.ContentRootPath, "Interface")),
                RequestPath = "",
                EnableDirectoryBrowsing = false
            });
            app.Run();
        }
    }
}
